#  Welcome to Fun With Flags! 

## This is a simple Menu Bar app for macOS 13  

After running it you will be able to show most of the country flags around the world in your menu bar.


